#ifndef PAYMENT_H
#define PAYMENT_H

class Payment {
public:
    virtual bool pay(double amt) = 0;
    virtual ~Payment() {}
};

#endif
