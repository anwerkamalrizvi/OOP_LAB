#ifndef CARD_H
#define CARD_H

#include "Payment.h"
#include <iostream>
#include <string>
using namespace std;

class Card : public Payment {
private:
    string num;
public:
    Card(string n) : num(n) {}

    bool pay(double amt) override {
        cout << "Paying PKR " << amt << " with Card..." << endl;
        if (num.length() == 16) {
            cout << "Payment Sucess!" << endl;
            return true;
        }
        cout << "Card ERROR!!!!!" << endl;
        return false;
    }
};

#endif
