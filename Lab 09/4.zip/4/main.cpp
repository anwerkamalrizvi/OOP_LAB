#include <iostream>
#include "Card.h"
#include "Wallet.h"
using namespace std;

int main() {
    Payment* p1 = new Card("5554228547752854");
    Payment* p2 = new Wallet(150.0);

    p1->pay(50.0);
    p2->pay(100.0);
    p2->pay(60.0); //Fail cmd
    p1->pay(60.0);
    
    delete p1;
    delete p2;
    return 0;
}
