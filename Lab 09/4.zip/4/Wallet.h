#ifndef WALLET_H
#define WALLET_H

#include "Payment.h"
#include <iostream>
using namespace std;

class Wallet : public Payment {
private:
    double bal;
public:
    Wallet(double b) : bal(b) {}

    bool pay(double amt) override {
        cout << "Paying Rupees " << amt << " with Wallet..." << endl;
        if (bal >= amt) {
            bal -= amt;
            cout << "Payment OK! New Balance is Rs: " << bal << endl;
            return true;
        }
        cout << "Not Enough Balance! You cant afford!!!" << endl;
        return false;
    }
};

#endif
