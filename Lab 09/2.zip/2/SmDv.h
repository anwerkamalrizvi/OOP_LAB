#ifndef SMDV_H //Smarrt device
#define SMDV_H

class SmartDevice {
public:
    virtual void turnOn() = 0;
    virtual void turnOff() = 0;
    virtual void getStatus() const = 0;
    virtual ~SmartDevice() {}
};

#endif
