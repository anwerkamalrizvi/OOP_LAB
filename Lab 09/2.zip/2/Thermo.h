#ifndef THERMO_H
#define THERMO_H

#include "SmDv.h"
#include <iostream>
using namespace std;

class Thermostat : public SmartDevice {
private:
    bool isOn;
    double temp;
public:
    Thermostat() : isOn(false), temp(22.0) {} 

    void turnOn() override {
        isOn = true;
        cout << "Thermostat turned ON." << endl;
    }

    void turnOff() override {
        isOn = false;
        cout << "Thermostat turned OFF." << endl;
    }

    void getStatus() const override {
        cout << "\nThermostat Status: " << (isOn ? "ON" : "OFF") << "\ntemp in celcius: " << temp<< endl;
    }
};

#endif
