#ifndef LIGHTBULB_H
#define LIGHTBULB_H

#include "SmDv.h"
#include <iostream>
using namespace std;

class LightBulb : public SmartDevice {
private:
    bool isOn;
    int bright;
public:
    LightBulb() : isOn(false), bright(0) {}

    void turnOn() override {
        isOn = true;
        bright = 100;
        cout << "LightBulb turned ON." << endl;
    }

    void turnOff() override {
        isOn = false;
        bright = 0;
        cout << "LightBulb turned OFF." << endl;
    }

    void getStatus() const override {
        cout << "\nLightBulb Status: " << (isOn ? "ON" : "OFF") << "\nbrightness in percent: " << bright<< endl;
    }
};

#endif
