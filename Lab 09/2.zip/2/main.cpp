#include <iostream>
#include "LightBulb.h"
#include "Thermo.h"
using namespace std;

int main() {
    SmartDevice* t = new Thermostat();
    SmartDevice* bulb = new LightBulb();

    bulb->turnOn();
    
    bulb->getStatus();
    bulb->turnOff();
    bulb->getStatus();

    t->turnOn();
    t->getStatus();
    t->turnOff();
    t->getStatus();

    t->turnOn();

    delete bulb;
    delete t;
    return 0;
}
