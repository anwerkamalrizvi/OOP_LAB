#include <iostream>
#include "Run.h"
#include "Cycle.h"
using namespace std;

int main() {
    Act* a1 = new Run(5.0, 30.0);   // 5 km
    Act* a2 = new Cycle(20.0, 1.5); // 20 km/h, 1.5 hr

    cout << "Calories Running: " << a1->burn() << endl;
    cout << "Calories Cycling: " << a2->burn() << endl;

    delete a1;
    delete a2;
    return 0;
}
