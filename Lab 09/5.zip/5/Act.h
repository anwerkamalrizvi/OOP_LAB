#ifndef ACT_H
#define ACT_H

class Act {
public:
    virtual double burn() const = 0;
    virtual ~Act() {}
};

#endif
