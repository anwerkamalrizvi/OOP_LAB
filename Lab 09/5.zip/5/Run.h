#ifndef RUN_H
#define RUN_H

#include "Act.h"

class Run : public Act {
private:
    double dist; //km mey
    double time; // in min
public:
    Run(double d, double t) : dist(d), time(t) {}

    double burn() const override {
        return (dist * 60); 
    }
};

#endif
