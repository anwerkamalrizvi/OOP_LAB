#ifndef CYCLE_H
#define CYCLE_H

#include "Act.h"

class Cycle : public Act {
private:
    double spd; // km/h
    double time; // hr
public:
    Cycle(double s, double t) : spd(s), time(t) {}

    double burn() const override {
        return (spd * time * 30); 
    }
};

#endif
