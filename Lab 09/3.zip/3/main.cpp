#include <iostream>
#include "Book.cpp"
using namespace std;

int main() {
    Book book1("Shikwa Jawab-e-Shikwa", "Allama Iqbal", "2449494992");

    cout << "Title: " << book1.getTitle() << endl;
    cout << "Author: " << book1.getAuthor() << endl;
    cout << "ISBN: " << book1.getISBN() << endl;

    return 0;
}
